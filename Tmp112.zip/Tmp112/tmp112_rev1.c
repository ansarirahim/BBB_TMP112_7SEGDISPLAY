// Distributed with a free-will license.
// Panther
// TMP112
// ver 1.0.0
// rev 1.0
// 26.10.17
// A. R. Ansari
#include<unistd.h>
#include <string.h>  // This contains utilities for modifying c-style string
#include <cstring> // This is the C++ version of the library above.  It effectively just puts everything in std::
#include <string>// this contains the std::string class. 
#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
//#include <sstream>
//#include <sstream>
//#include <iostream>
#include <string.h>
#include <limits.h>
using namespace std;
int  main(int argc , char **argv) 
{
	// Create I2C bus
float cTemp=0;
int delay_ms =atoi(argv[1]);
//stringstream stream;
//stream << fixed << setprecision(2) << pi;
//string s = stream.str();
//system("Display7Clear");
///// system("echo BB-UART4 > /sys/devices/bone_capemgr.9/slots");

///while(1)
system("systemctl stop DISPLAY7_TEMP.service");
{
	int file;
	char *bus = "/dev/i2c-1";
	if((file = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the i2c bus. \r\n");
		exit(1);
	}
	// Get I2C device, TMP112 I2C address is 0x48(72)
	ioctl(file, I2C_SLAVE, 0x48);

	// Select configuration register(0x01)
	// Continous Conversion mode, 12-Bit Resolution, Fault Queue is 1(0x60)
	// Polarity low, Thermostat in Comparator mode, Disables Shutdown mode(0xA0)
	char config[3] = {0};
	config[0] = 0x01;
	config[1] = 0x60;
	config[2] = 0xA0;
	write(file, config, 3);
for(int i=0;i<1000;i++)
	usleep(delay_ms);

	// Read 2 bytes of data from register(0x00)
	// temp msb, temp lsb
	char reg[1] = {0x00};
	write(file, reg, 1);
	char data[2] = {0};
	if(read(file, data, 2) != 2)
	{
		printf("ERROR: CONNECTION ERROR\r\n");
		exit(1);
	}
	else
	{
		// Convert the data to 12-bits
		int temp = (data[0] * 256 + data[1]) / 16;
		if(temp > 2047)
		{
			temp -= 4096;
		}
		 cTemp = temp * 0.0625;
		float fTemp = (cTemp * 1.8) + 32;
	
		// Output data to screen
		printf("TEMP=%.4f\r\n", cTemp);
		//printf("Temperature in Fahrenheit : %.2f F \n", fTemp);
	}



close(file);
}
system("stty -echo");
system("systemctl start DISPLAY7_TEMP.service");
system("systemctl enable DISPLAY7_TEMP.service");
}

