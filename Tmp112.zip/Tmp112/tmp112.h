#ifndef __TEMP112_H__
#define __TEMP112_H__
#define CALLIB_FILE "/root/Tmp112/callib"
#define MYBUFSIZE 100
#define COMMAND_DISPLAY7SEGSTRING  "/root/Tmp112/Display7SegmentString "

#define COMMAND_GET_TEMP_CALIB_DATA "GET_TEMP_CALIB_DATA"
#define ENABLE_UART4 "echo BB-UART4 > /sys/devices/bone_capemgr.9/slots"
#endif

